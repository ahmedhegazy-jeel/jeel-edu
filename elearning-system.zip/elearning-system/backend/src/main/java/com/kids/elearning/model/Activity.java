package com.kids.elearning.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "activities")
public class Activity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String title;
    private String description;
    private int orderNumber;
    
    @Enumerated(EnumType.STRING)
    private ActivityType type;
    
    // Content based on type
    private String content; // For TEXT type
    private String videoUrl; // For VIDEO type
    private String pdfUrl; // For PDF type
    private String externalUrl; // For EXTERNAL type
    private String quizData; // JSON string for quiz questions and answers
    private String imageUrls; // JSON array for images
    private String audioUrl; // For audio reading
    
    private boolean isActive;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "lesson_id")
    private Lesson lesson;
    
    public enum ActivityType {
        TEXT, VIDEO, PDF, QUIZ, EXTERNAL, GROUP_OF_PAGES, AUDIO
    }
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}