package com.kids.elearning.controller;

import com.kids.elearning.model.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getDashboard() {
        Map<String, Object> dashboard = new HashMap<>();
        dashboard.put("totalStudents", 450);
        dashboard.put("totalTeachers", 25);
        dashboard.put("totalCurriculums", 8);
        dashboard.put("totalSchools", 3);
        dashboard.put("recentActivity", Arrays.asList(
            "New student enrolled: Ahmed Hassan",
            "Curriculum updated: Mathematics Grade 1",
            "New teacher added: Sarah Ahmed"
        ));
        
        return ResponseEntity.ok(dashboard);
    }

    @GetMapping("/curriculums")
    public ResponseEntity<List<Curriculum>> getAllCurriculums() {
        // Mock curriculums for admin view
        List<Curriculum> curriculums = new ArrayList<>();
        
        Curriculum math = new Curriculum();
        math.setId(1L);
        math.setTitle("Adventures in Mathematics");
        math.setSubject("Math");
        math.setGradeLevel("Grade 1");
        math.setActive(true);
        curriculums.add(math);
        
        Curriculum english = new Curriculum();
        english.setId(2L);
        english.setTitle("Alphabet Adventures");
        english.setSubject("English");
        english.setGradeLevel("Grade 1");
        english.setActive(true);
        curriculums.add(english);
        
        return ResponseEntity.ok(curriculums);
    }

    @PostMapping("/curriculum")
    public ResponseEntity<Curriculum> createCurriculum(@RequestBody Curriculum curriculum) {
        curriculum.setId(System.currentTimeMillis()); // Mock ID generation
        return ResponseEntity.ok(curriculum);
    }

    @PutMapping("/curriculum/{id}")
    public ResponseEntity<Curriculum> updateCurriculum(@PathVariable Long id, @RequestBody Curriculum curriculum) {
        curriculum.setId(id);
        return ResponseEntity.ok(curriculum);
    }

    @DeleteMapping("/curriculum/{id}")
    public ResponseEntity<Void> deleteCurriculum(@PathVariable Long id) {
        return ResponseEntity.ok().build();
    }
}