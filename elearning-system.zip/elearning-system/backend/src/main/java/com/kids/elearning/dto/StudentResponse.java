package com.kids.elearning.dto;

import lombok.Data;
import java.util.List;

@Data
public class CurriculumResponse {
    private Long id;
    private String title;
    private String description;
    private String subject;
    private String gradeLevel;
    private List<UnitResponse> units;
    private double progressPercentage;
}

@Data
public class UnitResponse {
    private Long id;
    private String title;
    private String description;
    private int orderNumber;
    private String storyTitle;
    private String storyIntro;
    private String storyTheme;
    private String backgroundImageUrl;
    private List<LessonResponse> lessons;
    private double progressPercentage;
}

@Data
public class LessonResponse {
    private Long id;
    private String title;
    private String description;
    private int orderNumber;
    private int mapX;
    private int mapY;
    private String lessonIcon;
    private String storyElement;
    private String challengeDescription;
    private List<ActivityResponse> activities;
    private boolean isCompleted;
    private boolean isLocked;
    private boolean isAvailable;
}

@Data
public class ActivityResponse {
    private Long id;
    private String title;
    private String description;
    private int orderNumber;
    private String type;
    private String content;
    private String videoUrl;
    private String pdfUrl;
    private String externalUrl;
    private String imageUrls;
    private String audioUrl;
    private boolean isCompleted;
}