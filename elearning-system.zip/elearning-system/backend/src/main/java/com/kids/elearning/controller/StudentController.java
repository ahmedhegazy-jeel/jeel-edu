package com.kids.elearning.controller;

import com.kids.elearning.dto.StudentResponse;
import com.kids.elearning.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/student")
@CrossOrigin(origins = "*")
public class StudentController {

    // Mock data for demonstration
    private List<Curriculum> mockCurriculums = new ArrayList<>();
    private List<Unit> mockUnits = new ArrayList<>();
    private List<Lesson> mockLessons = new ArrayList<>();
    private List<Activity> mockActivities = new ArrayList<>();
    private Map<String, StudentProgress> mockProgress = new HashMap<>();

    public StudentController() {
        // Initialize mock data with storytelling elements
        initializeMockData();
    }

    private void initializeMockData() {
        // Create Math Curriculum
        Curriculum mathCurriculum = new Curriculum();
        mathCurriculum.setId(1L);
        mathCurriculum.setTitle("Adventures in Mathematics");
        mathCurriculum.setDescription("Join magical adventures while learning basic math!");
        mathCurriculum.setSubject("Math");
        mathCurriculum.setGradeLevel("Grade 1");
        mathCurriculum.setActive(true);
        
        // Create Unit 1: Numbers Kingdom
        Unit unit1 = new Unit();
        unit1.setId(1L);
        unit1.setTitle("The Numbers Kingdom");
        unit1.setDescription("Learn about numbers through a magical kingdom adventure!");
        unit1.setOrderNumber(1);
        unit1.setStoryTitle("Saving the Princess of Numbers");
        unit1.setStoryIntro("Welcome to the magical Numbers Kingdom! The evil Sorcerer of Confusion has scattered all the numbers across the land. As our brave learner, you must journey through the kingdom to find and restore each number to its rightful place. Only then can we save the Princess of Numbers!");
        unit1.setStoryTheme("fantasy");
        unit1.setBackgroundImageUrl("/images/kingdom-bg.jpg");
        unit1.setCurriculum(mathCurriculum);
        unit1.setActive(true);
        
        // Create lessons for unit 1
        Lesson lesson1 = new Lesson();
        lesson1.setId(1L);
        lesson1.setTitle("Numbers 1-5");
        lesson1.setDescription("Meet the first five numbers in our kingdom!");
        lesson1.setOrderNumber(1);
        lesson1.setMapX(50);
        lesson1.setMapY(100);
        lesson1.setLessonIcon("🌟");
        lesson1.setStoryElement("Find the golden stars that represent numbers 1-5");
        lesson1.setChallengeDescription("Help the villagers count their magical stars!");
        lesson1.setUnit(unit1);
        lesson1.setActive(true);
        
        Lesson lesson2 = new Lesson();
        lesson2.setId(2L);
        lesson2.setTitle("Numbers 6-10");
        lesson2.setDescription("Discover the next five numbers in our adventure!");
        lesson2.setOrderNumber(2);
        lesson2.setMapX(150);
        lesson2.setMapY(80);
        lesson2.setLessonIcon("💎");
        lesson2.setStoryElement("Collect the sparkling gems for numbers 6-10");
        lesson2.setChallengeDescription("Help the jeweler organize his precious gems!");
        lesson2.setUnit(unit1);
        lesson2.setActive(true);
        
        // Create activities for lessons
        Activity activity1 = new Activity();
        activity1.setId(1L);
        activity1.setTitle("Meet Number 1");
        activity1.setDescription("Learn about the number 1");
        activity1.setOrderNumber(1);
        activity1.setType(Activity.ActivityType.TEXT);
        activity1.setContent("Number 1 is special! It represents one magical star in our kingdom. Let's explore how to write this number and where we can find one of something!");
        activity1.setLesson(lesson1);
        activity1.setActive(true);
        
        Activity activity2 = new Activity();
        activity2.setId(2L);
        activity2.setTitle("Counting Stars");
        activity2.setDescription("Interactive counting game");
        activity2.setOrderNumber(2);
        activity2.setType(Activity.ActivityType.QUIZ);
        activity2.setQuizData("{\"questions\": [{\"question\": \"How many stars are there?\", \"options\": [\"1\", \"2\", \"3\"], \"correct\": 0}]}");
        activity2.setLesson(lesson1);
        activity2.setActive(true);
        
        // Add to lists
        mockCurriculums.add(mathCurriculum);
        mockUnits.add(unit1);
        mockLessons.addAll(Arrays.asList(lesson1, lesson2));
        mockActivities.addAll(Arrays.asList(activity1, activity2));
        
        // Create English Curriculum
        Curriculum englishCurriculum = new Curriculum();
        englishCurriculum.setId(2L);
        englishCurriculum.setTitle("Alphabet Adventures");
        englishCurriculum.setDescription("Explore the magical world of letters and words!");
        englishCurriculum.setSubject("English");
        englishCurriculum.setGradeLevel("Grade 1");
        englishCurriculum.setActive(true);
        
        mockCurriculums.add(englishCurriculum);
    }

    @GetMapping("/curriculums/{studentId}")
    public ResponseEntity<List<CurriculumResponse>> getStudentCurriculums(@PathVariable Long studentId) {
        // Mock student ID validation - in real app, this would check authentication
        if (studentId == null) {
            return ResponseEntity.badRequest().build();
        }

        List<CurriculumResponse> responses = mockCurriculums.stream()
            .map(this::convertToCurriculumResponse)
            .collect(Collectors.toList());

        return ResponseEntity.ok(responses);
    }

    @GetMapping("/curriculum/{curriculumId}/units")
    public ResponseEntity<List<UnitResponse>> getCurriculumUnits(@PathVariable Long curriculumId) {
        List<Unit> units = mockUnits.stream()
            .filter(unit -> unit.getCurriculum().getId().equals(curriculumId))
            .collect(Collectors.toList());

        List<UnitResponse> responses = units.stream()
            .map(this::convertToUnitResponse)
            .collect(Collectors.toList());

        return ResponseEntity.ok(responses);
    }

    @GetMapping("/unit/{unitId}/lessons")
    public ResponseEntity<List<LessonResponse>> getUnitLessons(@PathVariable Long unitId) {
        List<Lesson> lessons = mockLessons.stream()
            .filter(lesson -> lesson.getUnit().getId().equals(unitId))
            .collect(Collectors.toList());

        List<LessonResponse> responses = lessons.stream()
            .map(this::convertToLessonResponse)
            .collect(Collectors.toList());

        return ResponseEntity.ok(responses);
    }

    @GetMapping("/lesson/{lessonId}/activities")
    public ResponseEntity<List<ActivityResponse>> getLessonActivities(@PathVariable Long lessonId) {
        List<Activity> activities = mockActivities.stream()
            .filter(activity -> activity.getLesson().getId().equals(lessonId))
            .collect(Collectors.toList());

        List<ActivityResponse> responses = activities.stream()
            .map(this::convertToActivityResponse)
            .collect(Collectors.toList());

        return ResponseEntity.ok(responses);
    }

    @GetMapping("/lesson/{lessonId}")
    public ResponseEntity<LessonResponse> getLesson(@PathVariable Long lessonId) {
        Lesson lesson = mockLessons.stream()
            .filter(l -> l.getId().equals(lessonId))
            .findFirst()
            .orElse(null);

        if (lesson == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(convertToLessonResponse(lesson));
    }

    @GetMapping("/student-progress/{studentId}")
    public ResponseEntity<Map<String, Object>> getStudentProgress(@PathVariable Long studentId) {
        Map<String, Object> progress = new HashMap<>();
        progress.put("totalPoints", 150);
        progress.put("currentLevel", 2);
        progress.put("completedLessons", 3);
        progress.put("totalLessons", 8);
        progress.put("achievements", Arrays.asList("First Lesson", "Star Collector", "Quiz Master"));
        
        return ResponseEntity.ok(progress);
    }

    private CurriculumResponse convertToCurriculumResponse(Curriculum curriculum) {
        CurriculumResponse response = new CurriculumResponse();
        response.setId(curriculum.getId());
        response.setTitle(curriculum.getTitle());
        response.setDescription(curriculum.getDescription());
        response.setSubject(curriculum.getSubject());
        response.setGradeLevel(curriculum.getGradeLevel());
        
        // Mock progress calculation
        response.setProgressPercentage(25.0);
        
        return response;
    }

    private UnitResponse convertToUnitResponse(Unit unit) {
        UnitResponse response = new UnitResponse();
        response.setId(unit.getId());
        response.setTitle(unit.getTitle());
        response.setDescription(unit.getDescription());
        response.setOrderNumber(unit.getOrderNumber());
        response.setStoryTitle(unit.getStoryTitle());
        response.setStoryIntro(unit.getStoryIntro());
        response.setStoryTheme(unit.getStoryTheme());
        response.setBackgroundImageUrl(unit.getBackgroundImageUrl());
        
        // Mock progress calculation
        response.setProgressPercentage(30.0);
        
        return response;
    }

    private LessonResponse convertToLessonResponse(Lesson lesson) {
        LessonResponse response = new LessonResponse();
        response.setId(lesson.getId());
        response.setTitle(lesson.getTitle());
        response.setDescription(lesson.getDescription());
        response.setOrderNumber(lesson.getOrderNumber());
        response.setMapX(lesson.getMapX());
        response.setMapY(lesson.getMapY());
        response.setLessonIcon(lesson.getLessonIcon());
        response.setStoryElement(lesson.getStoryElement());
        response.setChallengeDescription(lesson.getChallengeDescription());
        
        // Mock status calculations
        response.setCompleted(lesson.getOrderNumber() <= 2); // First two lessons completed
        response.setLocked(lesson.getOrderNumber() > 3); // Lock lessons after 3rd
        response.setAvailable(lesson.getOrderNumber() <= 3); // Available up to 3rd lesson
        
        return response;
    }

    private ActivityResponse convertToActivityResponse(Activity activity) {
        ActivityResponse response = new ActivityResponse();
        response.setId(activity.getId());
        response.setTitle(activity.getTitle());
        response.setDescription(activity.getDescription());
        response.setOrderNumber(activity.getOrderNumber());
        response.setType(activity.getType().name());
        response.setContent(activity.getContent());
        response.setVideoUrl(activity.getVideoUrl());
        response.setPdfUrl(activity.getPdfUrl());
        response.setExternalUrl(activity.getExternalUrl());
        response.setImageUrls(activity.getImageUrls());
        response.setAudioUrl(activity.getAudioUrl());
        
        // Mock completion status
        response.setCompleted(activity.getOrderNumber() <= 1);
        
        return response;
    }
}