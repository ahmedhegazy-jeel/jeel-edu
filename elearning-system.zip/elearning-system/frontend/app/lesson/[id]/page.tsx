'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { ArrowLeft, Play, Book, FileText, Video, Image, ExternalLink, Volume2 } from 'lucide-react'
import { curriculumService } from '@/services/curriculumService'
import toast from 'react-hot-toast'

interface Activity {
  id: number
  title: string
  description: string
  orderNumber: number
  type: string
  content?: string
  videoUrl?: string
  pdfUrl?: string
  externalUrl?: string
  imageUrls?: string
  audioUrl?: string
  isCompleted: boolean
}

interface Lesson {
  id: number
  title: string
  description: string
  orderNumber: number
  storyElement: string
  challengeDescription: string
  activities: Activity[]
}

export default function LessonPage({ params }: { params: { id: string } }) {
  const [lesson, setLesson] = useState<Lesson | null>(null)
  const [currentActivityIndex, setCurrentActivityIndex] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadLesson()
  }, [params.id])

  const loadLesson = async () => {
    try {
      setLoading(true)
      // Mock lesson data for demonstration
      const mockLesson: Lesson = {
        id: parseInt(params.id),
        title: "Numbers 1-5",
        description: "Meet the first five numbers in our kingdom!",
        orderNumber: 1,
        storyElement: "Find the golden stars that represent numbers 1-5",
        challengeDescription: "Help the villagers count their magical stars!",
        activities: [
          {
            id: 1,
            title: "Meet Number 1",
            description: "Learn about the magical number 1",
            orderNumber: 1,
            type: "TEXT",
            content: "Welcome, brave learner! 🌟\n\nNumber 1 is very special in our kingdom. It represents one golden star that shines in the sky. Let's explore this amazing number together!\n\n✨ One star in the sky\n⭐ One magical wand\n🌟 One enchanted crown\n\nCan you think of other things that come in ones?",
            isCompleted: true
          },
          {
            id: 2,
            title: "Counting Stars Game",
            description: "Interactive counting adventure!",
            orderNumber: 2,
            type: "QUIZ",
            content: JSON.stringify({
              questions: [
                {
                  question: "How many golden stars are there?",
                  options: ["1", "2", "3", "4"],
                  correct: 0,
                  image: "⭐"
                },
                {
                  question: "If you have 1 star and someone gives you 1 more, how many do you have?",
                  options: ["1", "2", "3", "4"],
                  correct: 1,
                  image: "⭐ + ⭐"
                }
              ]
            }),
            isCompleted: false
          },
          {
            id: 3,
            title: "Video Adventure",
            description: "Watch the magical number story!",
            orderNumber: 3,
            type: "VIDEO",
            videoUrl: "/videos/number-1-story.mp4",
            isCompleted: false
          }
        ]
      }
      
      setLesson(mockLesson)
    } catch (error) {
      console.error('Error loading lesson:', error)
      toast.error('Failed to load lesson')
    } finally {
      setLoading(false)
    }
  }

  const getActivityIcon = (type: string) => {
    switch (type.toUpperCase()) {
      case 'TEXT':
        return <FileText className="w-5 h-5" />
      case 'VIDEO':
        return <Video className="w-5 h-5" />
      case 'PDF':
        return <Book className="w-5 h-5" />
      case 'QUIZ':
        return <Play className="w-5 h-5" />
      case 'EXTERNAL':
        return <ExternalLink className="w-5 h-5" />
      case 'AUDIO':
        return <Volume2 className="w-5 h-5" />
      default:
        return <Image className="w-5 h-5" />
    }
  }

  const getActivityColor = (type: string) => {
    switch (type.toUpperCase()) {
      case 'TEXT':
        return 'from-blue-400 to-blue-600'
      case 'VIDEO':
        return 'from-red-400 to-red-600'
      case 'PDF':
        return 'from-green-400 to-green-600'
      case 'QUIZ':
        return 'from-purple-400 to-purple-600'
      case 'EXTERNAL':
        return 'from-orange-400 to-orange-600'
      case 'AUDIO':
        return 'from-pink-400 to-pink-600'
      default:
        return 'from-gray-400 to-gray-600'
    }
  }

  const handleActivityComplete = (activityId: number) => {
    if (lesson) {
      const updatedActivities = lesson.activities.map(activity =>
        activity.id === activityId
          ? { ...activity, isCompleted: true }
          : activity
      )
      setLesson({ ...lesson, activities: updatedActivities })
      
      if (currentActivityIndex < lesson.activities.length - 1) {
        setCurrentActivityIndex(currentActivityIndex + 1)
        toast.success('Great job! Moving to next activity! 🎉')
      } else {
        toast.success('Lesson completed! You earned 10 points! ⭐')
      }
    }
  }

  const renderActivityContent = (activity: Activity) => {
    switch (activity.type.toUpperCase()) {
      case 'TEXT':
        return (
          <div className="prose prose-lg max-w-none">
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-2xl border-2 border-blue-200">
              <div className="whitespace-pre-wrap text-gray-800 leading-relaxed">
                {activity.content}
              </div>
            </div>
          </div>
        )
      
      case 'QUIZ':
        const quizData = activity.content ? JSON.parse(activity.content) : null
        if (quizData && quizData.questions) {
          return (
            <div className="space-y-6">
              {quizData.questions.map((question: any, qIndex: number) => (
                <motion.div
                  key={qIndex}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: qIndex * 0.2 }}
                  className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-2xl border-2 border-purple-200"
                >
                  <div className="text-center mb-4">
                    <div className="text-4xl mb-2">{question.image}</div>
                    <h3 className="text-xl font-bold text-gray-800 kid-friendly">
                      {question.question}
                    </h3>
                  </div>
                  
                  <div className="grid grid-cols-1 gap-3">
                    {question.options.map((option: string, oIndex: number) => (
                      <motion.button
                        key={oIndex}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="bg-white p-4 rounded-xl border-2 border-purple-200 hover:border-purple-400 transition-colors text-left"
                        onClick={() => {
                          if (oIndex === question.correct) {
                            handleActivityComplete(activity.id)
                          } else {
                            toast.error('Try again! You can do it! 💪')
                          }
                        }}
                      >
                        <span className="font-medium">{option}</span>
                      </motion.button>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          )
        }
        break
      
      case 'VIDEO':
        return (
          <div className="bg-gray-100 p-8 rounded-2xl text-center">
            <Video className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-800 mb-2">Video Content</h3>
            <p className="text-gray-600 mb-4">Video would play here in the full version</p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-to-r from-red-400 to-red-600 text-white px-6 py-3 rounded-full font-semibold"
            >
              <Play className="w-4 h-4 inline mr-2" />
              Play Video
            </motion.button>
          </div>
        )
      
      default:
        return (
          <div className="bg-gray-100 p-8 rounded-2xl text-center">
            <FileText className="w-16 h-16 text-gray-500 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-800 mb-2">{activity.type} Content</h3>
            <p className="text-gray-600">This activity type will be implemented in the full version</p>
          </div>
        )
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-500 to-red-500 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="text-white text-6xl"
        >
          📚
        </motion.div>
      </div>
    )
  }

  if (!lesson) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-500 to-red-500 flex items-center justify-center">
        <div className="text-center text-white">
          <div className="text-6xl mb-4">📚</div>
          <h2 className="text-2xl font-bold mb-2">Lesson Not Found</h2>
          <button
            onClick={() => window.history.back()}
            className="kid-button"
          >
            Go Back
          </button>
        </div>
      </div>
    )
  }

  const currentActivity = lesson.activities[currentActivityIndex]

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-500 to-red-500">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-sm border-b border-white/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => window.history.back()}
              className="flex items-center space-x-2 bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-full hover:bg-white/30 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Adventure</span>
            </button>
            
            <div className="text-white text-center">
              <h1 className="text-xl font-bold kid-friendly">{lesson.title}</h1>
              <p className="text-sm text-white/80">Activity {currentActivityIndex + 1} of {lesson.activities.length}</p>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className="w-32 progress-bar h-2">
                <motion.div
                  className="progress-fill"
                  initial={{ width: 0 }}
                  animate={{ width: `${((currentActivityIndex + 1) / lesson.activities.length) * 100}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Story Context */}
        <motion.div
          initial={{ y: -30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-center mb-8"
        >
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 text-white">
            <h2 className="text-2xl font-bold kid-friendly mb-2">
              {lesson.storyElement}
            </h2>
            <p className="text-lg">
              {lesson.challengeDescription}
            </p>
          </div>
        </motion.div>

        {/* Activity Navigation */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8"
        >
          {lesson.activities.map((activity, index) => (
            <motion.button
              key={activity.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setCurrentActivityIndex(index)}
              className={`p-4 rounded-2xl border-2 transition-all ${
                index === currentActivityIndex
                  ? 'bg-white border-white shadow-lg'
                  : index < currentActivityIndex
                  ? 'bg-green-500/20 border-green-400'
                  : 'bg-white/10 border-white/30'
              } ${activity.isCompleted ? 'opacity-75' : ''}`}
            >
              <div className="flex flex-col items-center space-y-2 text-white">
                <div className={`p-2 rounded-full bg-gradient-to-r ${getActivityColor(activity.type)}`}>
                  {activity.isCompleted ? '✅' : getActivityIcon(activity.type)}
                </div>
                <span className="text-sm font-medium text-center">
                  {activity.title}
                </span>
              </div>
            </motion.button>
          ))}
        </motion.div>

        {/* Current Activity Content */}
        <motion.div
          key={currentActivityIndex}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-white rounded-3xl p-8 shadow-xl"
        >
          <div className="mb-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className={`p-3 rounded-full bg-gradient-to-r ${getActivityColor(currentActivity.type)}`}>
                {getActivityIcon(currentActivity.type)}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-800 kid-friendly">
                  {currentActivity.title}
                </h2>
                <p className="text-gray-600">
                  {currentActivity.description}
                </p>
              </div>
            </div>
          </div>

          {/* Activity Content */}
          <div className="mb-8">
            {renderActivityContent(currentActivity)}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-between items-center">
            <button
              onClick={() => currentActivityIndex > 0 && setCurrentActivityIndex(currentActivityIndex - 1)}
              disabled={currentActivityIndex === 0}
              className="px-6 py-3 bg-gray-200 text-gray-700 rounded-full font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Previous
            </button>

            <div className="flex items-center space-x-4">
              {currentActivityIndex < lesson.activities.length - 1 ? (
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setCurrentActivityIndex(currentActivityIndex + 1)}
                  className="kid-button"
                >
                  Next Activity →
                </motion.button>
              ) : (
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    handleActivityComplete(currentActivity.id)
                    setTimeout(() => {
                      window.history.back()
                    }, 2000)
                  }}
                  className="bg-gradient-to-r from-green-400 to-emerald-600 hover:from-green-500 hover:to-emerald-700 text-white font-bold py-3 px-8 rounded-full shadow-lg"
                >
                  🎉 Complete Lesson!
                </motion.button>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}