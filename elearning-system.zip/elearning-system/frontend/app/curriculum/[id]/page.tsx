'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { ArrowLeft, BookOpen } from 'lucide-react'
import AdventureMap from '@/components/AdventureMap'
import { curriculumService } from '@/services/curriculumService'
import toast from 'react-hot-toast'

interface Unit {
  id: number
  title: string
  description: string
  orderNumber: number
  storyTitle: string
  storyIntro: string
  storyTheme: string
  backgroundImageUrl: string
  lessons: Lesson[]
  progressPercentage: number
}

interface Lesson {
  id: number
  title: string
  description: string
  orderNumber: number
  mapX: number
  mapY: number
  lessonIcon: string
  storyElement: string
  challengeDescription: string
  isCompleted: boolean
  isLocked: boolean
  isAvailable: boolean
}

interface Curriculum {
  id: number
  title: string
  description: string
  subject: string
  gradeLevel: string
  units: Unit[]
  progressPercentage: number
}

export default function CurriculumPage({ params }: { params: { id: string } }) {
  const [curriculum, setCurriculum] = useState<Curriculum | null>(null)
  const [selectedUnit, setSelectedUnit] = useState<Unit | null>(null)
  const [loading, setLoading] = useState(true)
  const [showMap, setShowMap] = useState(false)

  useEffect(() => {
    loadCurriculum()
  }, [params.id])

  const loadCurriculum = async () => {
    try {
      setLoading(true)
      // Mock curriculum data for now
      const mockCurriculum: Curriculum = {
        id: parseInt(params.id),
        title: "Adventures in Mathematics",
        description: "Join magical adventures while learning basic math!",
        subject: "Math",
        gradeLevel: "Grade 1",
        progressPercentage: 25.0,
        units: [
          {
            id: 1,
            title: "The Numbers Kingdom",
            description: "Learn about numbers through a magical kingdom adventure!",
            orderNumber: 1,
            storyTitle: "Saving the Princess of Numbers",
            storyIntro: "Welcome to the magical Numbers Kingdom! The evil Sorcerer of Confusion has scattered all the numbers across the land. As our brave learner, you must journey through the kingdom to find and restore each number to its rightful place. Only then can we save the Princess of Numbers!",
            storyTheme: "fantasy",
            backgroundImageUrl: "/images/kingdom-bg.jpg",
            progressPercentage: 30.0,
            lessons: [
              {
                id: 1,
                title: "Numbers 1-5",
                description: "Meet the first five numbers in our kingdom!",
                orderNumber: 1,
                mapX: 100,
                mapY: 200,
                lessonIcon: "🌟",
                storyElement: "Find the golden stars that represent numbers 1-5",
                challengeDescription: "Help the villagers count their magical stars!",
                isCompleted: true,
                isLocked: false,
                isAvailable: true
              },
              {
                id: 2,
                title: "Numbers 6-10",
                description: "Discover the next five numbers in our adventure!",
                orderNumber: 2,
                mapX: 250,
                mapY: 180,
                lessonIcon: "💎",
                storyElement: "Collect the sparkling gems for numbers 6-10",
                challengeDescription: "Help the jeweler organize his precious gems!",
                isCompleted: true,
                isLocked: false,
                isAvailable: true
              },
              {
                id: 3,
                title: "Number Comparisons",
                description: "Learn which numbers are bigger or smaller!",
                orderNumber: 3,
                mapX: 400,
                mapY: 220,
                lessonIcon: "⚖️",
                storyElement: "Help the kingdom's fair judge compare the numbers",
                challengeDescription: "Sort the numbers by size with the royal judge!",
                isCompleted: false,
                isLocked: false,
                isAvailable: true
              },
              {
                id: 4,
                title: "Simple Addition",
                description: "Learn how to add numbers together!",
                orderNumber: 4,
                mapX: 550,
                mapY: 160,
                lessonIcon: "➕",
                storyElement: "Combine magical items to create new treasures",
                challengeDescription: "Help the kingdom's alchemist mix ingredients!",
                isCompleted: false,
                isLocked: true,
                isAvailable: false
              }
            ]
          }
        ]
      }
      
      setCurriculum(mockCurriculum)
      if (mockCurriculum.units.length > 0) {
        setSelectedUnit(mockCurriculum.units[0])
      }
    } catch (error) {
      console.error('Error loading curriculum:', error)
      toast.error('Failed to load curriculum')
    } finally {
      setLoading(false)
    }
  }

  const handleUnitSelect = (unit: Unit) => {
    setSelectedUnit(unit)
    setShowMap(false)
  }

  const handleLessonSelect = (lesson: Lesson) => {
    if (lesson.isAvailable) {
      toast.success(`Starting lesson: ${lesson.title}!`)
      // Navigate to lesson content page
      window.location.href = `/lesson/${lesson.id}`
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="text-white text-6xl"
        >
          🔢
        </motion.div>
      </div>
    )
  }

  if (!curriculum) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500 flex items-center justify-center">
        <div className="text-center text-white">
          <div className="text-6xl mb-4">📚</div>
          <h2 className="text-2xl font-bold mb-2">Curriculum Not Found</h2>
          <button
            onClick={() => window.location.href = '/'}
            className="kid-button"
          >
            Back to Home
          </button>
        </div>
      </div>
    )
  }

  if (showMap && selectedUnit) {
    return (
      <div className="min-h-screen">
        {/* Back Button */}
        <div className="absolute top-4 left-4 z-30">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowMap(false)}
            className="flex items-center space-x-2 bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-full hover:bg-white/30 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Units</span>
          </motion.button>
        </div>

        <AdventureMap
          unitTitle={selectedUnit.title}
          storyTitle={selectedUnit.storyTitle}
          storyIntro={selectedUnit.storyIntro}
          storyTheme={selectedUnit.storyTheme}
          backgroundImageUrl={selectedUnit.backgroundImageUrl}
          lessons={selectedUnit.lessons}
          onLessonSelect={handleLessonSelect}
        />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{ y: [0, -20, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-20 left-10 text-6xl opacity-20"
        >
          📖
        </motion.div>
        <motion.div
          animate={{ y: [0, -30, 0] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="absolute top-40 right-20 text-4xl opacity-20"
        >
          ✏️
        </motion.div>
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <motion.div
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="flex items-center justify-between mb-8"
        >
          <button
            onClick={() => window.location.href = '/'}
            className="flex items-center space-x-2 bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-full hover:bg-white/30 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Curriculums</span>
          </button>
        </motion.div>

        {/* Curriculum Info */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-4 kid-friendly">
            {curriculum.title}
          </h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto mb-6">
            {curriculum.description}
          </p>
          
          <div className="flex items-center justify-center space-x-6 text-white">
            <span className="bg-white/20 px-4 py-2 rounded-full">
              📚 {curriculum.subject}
            </span>
            <span className="bg-white/20 px-4 py-2 rounded-full">
              🎓 {curriculum.gradeLevel}
            </span>
            <span className="bg-white/20 px-4 py-2 rounded-full">
              ⭐ {Math.round(curriculum.progressPercentage)}% Complete
            </span>
          </div>
        </motion.div>

        {/* Units Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-white text-center mb-8 kid-friendly">
            Learning Adventures 🗺️
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {curriculum.units.map((unit, index) => (
              <motion.div
                key={unit.id}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="kid-card cursor-pointer h-full overflow-hidden"
                onClick={() => handleUnitSelect(unit)}
              >
                {/* Unit Header */}
                <div className={`bg-gradient-to-r ${
                  unit.storyTheme === 'fantasy' ? 'from-purple-500 to-pink-500' :
                  unit.storyTheme === 'space' ? 'from-blue-900 to-indigo-900' :
                  unit.storyTheme === 'ocean' ? 'from-blue-400 to-teal-500' :
                  'from-green-400 to-emerald-500'
                } p-4 rounded-t-2xl -m-6 mb-4`}>
                  <div className="flex items-center justify-between text-white">
                    <div className="text-3xl">
                      {unit.storyTheme === 'fantasy' ? '🏰' :
                       unit.storyTheme === 'space' ? '🚀' :
                       unit.storyTheme === 'ocean' ? '🏝️' : '🌲'}
                    </div>
                    <BookOpen className="w-6 h-6 opacity-80" />
                  </div>
                </div>

                {/* Content */}
                <div className="space-y-4">
                  <div>
                    <h3 className="text-xl font-bold text-gray-800 kid-friendly mb-2">
                      {unit.title}
                    </h3>
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {unit.description}
                    </p>
                  </div>

                  {/* Story Theme */}
                  <div className="flex items-center justify-between">
                    <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium">
                      🎭 {unit.storyTheme}
                    </span>
                    <span className="text-gray-500 text-sm">
                      Unit {unit.orderNumber}
                    </span>
                  </div>

                  {/* Progress */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Progress</span>
                      <span className="text-sm font-semibold text-gray-800">
                        {Math.round(unit.progressPercentage)}%
                      </span>
                    </div>
                    <div className="progress-bar h-3">
                      <motion.div
                        className="progress-fill"
                        initial={{ width: 0 }}
                        animate={{ width: `${unit.progressPercentage}%` }}
                        transition={{ duration: 1, delay: 0.5 }}
                      />
                    </div>
                  </div>

                  {/* Action Button */}
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full bg-gradient-to-r from-primary-500 to-primary-600 text-white py-3 px-4 rounded-xl font-semibold flex items-center justify-center space-x-2"
                  >
                    <span>Start Adventure</span>
                    <motion.span
                      animate={{ x: [0, 5, 0] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    >
                      →
                    </motion.span>
                  </motion.button>
                </div>

                {/* Floating decorations */}
                <div className="absolute top-4 right-4 opacity-10">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                    className="text-2xl"
                  >
                    ✨
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Adventure Map Button */}
        {selectedUnit && (
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-center"
          >
            <button
              onClick={() => setShowMap(true)}
              className="kid-button-secondary text-lg px-8 py-4 inline-flex items-center space-x-3"
            >
              <span>🗺️ Open Adventure Map</span>
              <motion.span
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                ⚡
              </motion.span>
            </button>
          </motion.div>
        )}
      </div>
    </div>
  )
}