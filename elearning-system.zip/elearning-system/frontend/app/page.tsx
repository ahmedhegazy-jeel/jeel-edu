'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Book, Star, Award, TrendingUp } from 'lucide-react'
import CurriculumCard from '@/components/CurriculumCard'
import ProgressHeader from '@/components/ProgressHeader'
import { curriculumService } from '@/services/curriculumService'

interface Curriculum {
  id: number
  title: string
  description: string
  subject: string
  gradeLevel: string
  progressPercentage: number
}

interface StudentProgress {
  totalPoints: number
  currentLevel: number
  completedLessons: number
  totalLessons: number
  achievements: string[]
}

export default function HomePage() {
  const [curriculums, setCurriculums] = useState<Curriculum[]>([])
  const [studentProgress, setStudentProgress] = useState<StudentProgress | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      setLoading(true)
      const studentId = 1 // Mock student ID
      const [curriculumsData, progressData] = await Promise.all([
        curriculumService.getStudentCurriculums(studentId),
        curriculumService.getStudentProgress(studentId)
      ])
      
      setCurriculums(curriculumsData)
      setStudentProgress(progressData)
    } catch (error) {
      console.error('Error loading data:', error)
    } finally {
      setLoading(false)
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-500 to-red-500 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="text-white text-6xl"
        >
          ⭐
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-500 to-red-500">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{ y: [0, -20, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-20 left-10 text-6xl opacity-20"
        >
          🌟
        </motion.div>
        <motion.div
          animate={{ y: [0, -30, 0] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="absolute top-40 right-20 text-4xl opacity-20"
        >
          🎈
        </motion.div>
        <motion.div
          animate={{ y: [0, -15, 0] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 2 }}
          className="absolute bottom-40 left-20 text-5xl opacity-20"
        >
          🦋
        </motion.div>
        <motion.div
          animate={{ y: [0, -25, 0] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
          className="absolute bottom-20 right-10 text-4xl opacity-20"
        >
          🌈
        </motion.div>
      </div>

      <div className="relative z-10">
        {/* Progress Header */}
        {studentProgress && <ProgressHeader progress={studentProgress} />}

        {/* Main Content */}
        <div className="container mx-auto px-4 py-8">
          {/* Welcome Section */}
          <motion.div
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4 kid-friendly">
              Welcome to Your Learning Adventure! 🚀
            </h1>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Choose your magical learning journey and unlock amazing adventures!
            </p>
          </motion.div>

          {/* Stats Row */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12"
          >
            <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4 text-center">
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Book className="w-8 h-8 text-white mx-auto mb-2" />
              </motion.div>
              <div className="text-2xl font-bold text-white">{curriculums.length}</div>
              <div className="text-white/80 text-sm">Curriculums</div>
            </div>
            
            <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4 text-center">
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <Star className="w-8 h-8 text-white mx-auto mb-2" />
              </motion.div>
              <div className="text-2xl font-bold text-white">{studentProgress?.totalPoints || 0}</div>
              <div className="text-white/80 text-sm">Total Stars</div>
            </div>
            
            <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4 text-center">
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Award className="w-8 h-8 text-white mx-auto mb-2" />
              </motion.div>
              <div className="text-2xl font-bold text-white">{studentProgress?.currentLevel || 1}</div>
              <div className="text-white/80 text-sm">Level</div>
            </div>
            
            <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4 text-center">
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
              >
                <TrendingUp className="w-8 h-8 text-white mx-auto mb-2" />
              </motion.div>
              <div className="text-2xl font-bold text-white">
                {studentProgress ? Math.round((studentProgress.completedLessons / studentProgress.totalLessons) * 100) : 0}%
              </div>
              <div className="text-white/80 text-sm">Progress</div>
            </div>
          </motion.div>

          {/* Curriculum Cards */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {curriculums.map((curriculum, index) => (
              <motion.div key={curriculum.id} variants={itemVariants}>
                <CurriculumCard 
                  curriculum={curriculum}
                  onClick={() => {
                    // Navigate to curriculum details
                    window.location.href = `/curriculum/${curriculum.id}`
                  }}
                />
              </motion.div>
            ))}
          </motion.div>

          {curriculums.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-20"
            >
              <div className="text-6xl mb-4">📚</div>
              <h3 className="text-2xl font-bold text-white mb-2">No Curriculums Available</h3>
              <p className="text-white/80">Your teacher will assign curriculums soon!</p>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  )
}