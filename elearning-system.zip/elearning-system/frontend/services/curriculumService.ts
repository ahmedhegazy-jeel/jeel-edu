import axios from 'axios'

const API_BASE_URL = 'http://localhost:8080/api'

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
})

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    console.error('API Error:', error)
    return Promise.reject(error)
  }
)

export const curriculumService = {
  // Student endpoints
  getStudentCurriculums: async (studentId: number) => {
    try {
      const response = await api.get(`/student/curriculums/${studentId}`)
      return response
    } catch (error) {
      console.error('Error fetching curriculums:', error)
      return []
    }
  },

  getCurriculumUnits: async (curriculumId: number) => {
    try {
      const response = await api.get(`/student/curriculum/${curriculumId}/units`)
      return response
    } catch (error) {
      console.error('Error fetching units:', error)
      return []
    }
  },

  getUnitLessons: async (unitId: number) => {
    try {
      const response = await api.get(`/student/unit/${unitId}/lessons`)
      return response
    } catch (error) {
      console.error('Error fetching lessons:', error)
      return []
    }
  },

  getLessonActivities: async (lessonId: number) => {
    try {
      const response = await api.get(`/student/lesson/${lessonId}/activities`)
      return response
    } catch (error) {
      console.error('Error fetching activities:', error)
      return []
    }
  },

  getLesson: async (lessonId: number) => {
    try {
      const response = await api.get(`/student/lesson/${lessonId}`)
      return response
    } catch (error) {
      console.error('Error fetching lesson:', error)
      return null
    }
  },

  getStudentProgress: async (studentId: number) => {
    try {
      const response = await api.get(`/student/student-progress/${studentId}`)
      return response
    } catch (error) {
      console.error('Error fetching progress:', error)
      return {
        totalPoints: 0,
        currentLevel: 1,
        completedLessons: 0,
        totalLessons: 0,
        achievements: []
      }
    }
  },

  // Admin endpoints
  getDashboard: async () => {
    try {
      const response = await api.get('/admin/dashboard')
      return response
    } catch (error) {
      console.error('Error fetching dashboard:', error)
      return {}
    }
  },

  getAllCurriculums: async () => {
    try {
      const response = await api.get('/admin/curriculums')
      return response
    } catch (error) {
      console.error('Error fetching all curriculums:', error)
      return []
    }
  },

  createCurriculum: async (curriculum: any) => {
    try {
      const response = await api.post('/admin/curriculum', curriculum)
      return response
    } catch (error) {
      console.error('Error creating curriculum:', error)
      throw error
    }
  },

  updateCurriculum: async (id: number, curriculum: any) => {
    try {
      const response = await api.put(`/admin/curriculum/${id}`, curriculum)
      return response
    } catch (error) {
      console.error('Error updating curriculum:', error)
      throw error
    }
  },

  deleteCurriculum: async (id: number) => {
    try {
      const response = await api.delete(`/admin/curriculum/${id}`)
      return response
    } catch (error) {
      console.error('Error deleting curriculum:', error)
      throw error
    }
  }
}