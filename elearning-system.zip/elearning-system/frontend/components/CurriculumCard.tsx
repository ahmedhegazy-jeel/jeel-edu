'use client'

import { motion } from 'framer-motion'
import { ChevronRight, BookOpen } from 'lucide-react'

interface Curriculum {
  id: number
  title: string
  description: string
  subject: string
  gradeLevel: string
  progressPercentage: number
}

interface CurriculumCardProps {
  curriculum: Curriculum
  onClick: () => void
}

const CurriculumCard = ({ curriculum, onClick }: CurriculumCardProps) => {
  const getSubjectColor = (subject: string) => {
    switch (subject.toLowerCase()) {
      case 'math':
        return 'from-blue-400 to-blue-600'
      case 'english':
        return 'from-green-400 to-green-600'
      case 'arabic':
        return 'from-purple-400 to-purple-600'
      case 'science':
        return 'from-emerald-400 to-emerald-600'
      default:
        return 'from-pink-400 to-pink-600'
    }
  }

  const getSubjectEmoji = (subject: string) => {
    switch (subject.toLowerCase()) {
      case 'math':
        return '🔢'
      case 'english':
        return '📖'
      case 'arabic':
        return '🕌'
      case 'science':
        return '🧪'
      default:
        return '📚'
    }
  }

  return (
    <motion.div
      whileHover={{ scale: 1.05, rotateY: 5 }}
      whileTap={{ scale: 0.95 }}
      className="kid-card cursor-pointer h-full overflow-hidden"
      onClick={onClick}
    >
      {/* Subject Icon */}
      <div className={`bg-gradient-to-r ${getSubjectColor(curriculum.subject)} p-4 rounded-t-2xl -m-6 mb-4`}>
        <div className="flex items-center justify-between text-white">
          <div className="text-4xl">{getSubjectEmoji(curriculum.subject)}</div>
          <BookOpen className="w-6 h-6 opacity-80" />
        </div>
      </div>

      {/* Content */}
      <div className="space-y-4">
        <div>
          <h3 className="text-xl font-bold text-gray-800 kid-friendly mb-2">
            {curriculum.title}
          </h3>
          <p className="text-gray-600 text-sm leading-relaxed">
            {curriculum.description}
          </p>
        </div>

        {/* Subject Badge */}
        <div className="flex items-center justify-between">
          <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium">
            {curriculum.subject}
          </span>
          <span className="text-gray-500 text-sm">
            {curriculum.gradeLevel}
          </span>
        </div>

        {/* Progress */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Progress</span>
            <span className="text-sm font-semibold text-gray-800">
              {Math.round(curriculum.progressPercentage)}%
            </span>
          </div>
          <div className="progress-bar h-3">
            <motion.div
              className="progress-fill"
              initial={{ width: 0 }}
              animate={{ width: `${curriculum.progressPercentage}%` }}
              transition={{ duration: 1, delay: 0.5 }}
            />
          </div>
        </div>

        {/* Action Button */}
        <motion.div
          whileHover={{ x: 5 }}
          className="flex items-center justify-center space-x-2 bg-gradient-to-r from-primary-500 to-primary-600 text-white py-3 px-4 rounded-xl font-semibold group"
        >
          <span>Continue Adventure</span>
          <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </motion.div>
      </div>

      {/* Floating decorations */}
      <div className="absolute top-4 right-4 opacity-10">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
          className="text-3xl"
        >
          ✨
        </motion.div>
      </div>
    </motion.div>
  )
}

export default CurriculumCard