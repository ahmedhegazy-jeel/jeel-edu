'use client'

import { motion } from 'framer-motion'
import { Star, Trophy, Zap, User } from 'lucide-react'

interface StudentProgress {
  totalPoints: number
  currentLevel: number
  completedLessons: number
  totalLessons: number
  achievements: string[]
}

interface ProgressHeaderProps {
  progress: StudentProgress
}

const ProgressHeader = ({ progress }: ProgressHeaderProps) => {
  const levelProgress = (progress.currentLevel - 1) / 10 // Assuming max level 10
  const lessonProgress = progress.completedLessons / progress.totalLessons

  return (
    <div className="bg-white/10 backdrop-blur-sm border-b border-white/20">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Profile Section */}
          <motion.div
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
            className="flex items-center space-x-4"
          >
            <motion.div
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              className="w-16 h-16 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full flex items-center justify-center shadow-lg"
            >
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-2xl"
              >
                🦄
              </motion.div>
            </motion.div>
            
            <div className="text-white">
              <h2 className="text-xl font-bold kid-friendly">Ahmed Hassan</h2>
              <div className="flex items-center space-x-2 text-sm text-white/80">
                <Zap className="w-4 h-4" />
                <span>Level {progress.currentLevel}</span>
              </div>
            </div>
          </motion.div>

          {/* Progress Indicators */}
          <motion.div
            initial={{ y: -30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="hidden md:flex items-center space-x-8"
          >
            {/* Stars */}
            <motion.div
              whileHover={{ scale: 1.1 }}
              className="flex items-center space-x-2 bg-white/10 rounded-full px-4 py-2"
            >
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Star className="w-5 h-5 text-yellow-400 fill-current" />
              </motion.div>
              <span className="text-white font-semibold">{progress.totalPoints}</span>
            </motion.div>

            {/* Level Progress */}
            <div className="flex items-center space-x-2">
              <div className="w-32">
                <div className="flex justify-between text-xs text-white/80 mb-1">
                  <span>Level {progress.currentLevel}</span>
                  <span>{progress.currentLevel + 1}</span>
                </div>
                <div className="progress-bar h-2">
                  <motion.div
                    className="progress-fill bg-gradient-to-r from-purple-400 to-pink-500"
                    initial={{ width: 0 }}
                    animate={{ width: `${levelProgress * 100}%` }}
                    transition={{ duration: 1, delay: 0.8 }}
                  />
                </div>
              </div>
            </div>

            {/* Achievements */}
            <motion.div
              whileHover={{ scale: 1.1 }}
              className="flex items-center space-x-2 bg-white/10 rounded-full px-4 py-2"
            >
              <Trophy className="w-5 h-5 text-yellow-400" />
              <span className="text-white font-semibold">{progress.achievements.length}</span>
            </motion.div>

            {/* Lesson Progress */}
            <div className="text-center">
              <div className="text-white font-semibold text-sm">
                {progress.completedLessons}/{progress.totalLessons}
              </div>
              <div className="text-white/80 text-xs">Lessons</div>
            </div>
          </motion.div>

          {/* Mobile Progress Indicator */}
          <motion.div
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="md:hidden flex items-center space-x-4 text-white"
          >
            <div className="text-center">
              <div className="text-lg font-bold">{progress.totalPoints}</div>
              <div className="text-xs">Stars</div>
            </div>
            <div className="w-20 progress-bar h-2">
              <motion.div
                className="progress-fill"
                initial={{ width: 0 }}
                animate={{ width: `${lessonProgress * 100}%` }}
                transition={{ duration: 1, delay: 0.6 }}
              />
            </div>
          </motion.div>
        </div>

        {/* Mobile Achievements */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="md:hidden mt-4 flex flex-wrap gap-2"
        >
          {progress.achievements.slice(0, 3).map((achievement, index) => (
            <motion.span
              key={index}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.4, delay: 1 + index * 0.1 }}
              className="bg-white/10 text-white text-xs px-2 py-1 rounded-full"
            >
              🏆 {achievement}
            </motion.span>
          ))}
          {progress.achievements.length > 3 && (
            <span className="bg-white/10 text-white text-xs px-2 py-1 rounded-full">
              +{progress.achievements.length - 3} more
            </span>
          )}
        </motion.div>
      </div>
    </div>
  )
}

export default ProgressHeader