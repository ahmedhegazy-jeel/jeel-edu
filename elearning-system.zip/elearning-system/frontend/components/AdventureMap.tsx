'use client'

import { motion } from 'framer-motion'
import { Lock, CheckCircle, Play } from 'lucide-react'

interface Lesson {
  id: number
  title: string
  description: string
  orderNumber: number
  mapX: number
  mapY: number
  lessonIcon: string
  storyElement: string
  challengeDescription: string
  isCompleted: boolean
  isLocked: boolean
  isAvailable: boolean
}

interface AdventureMapProps {
  unitTitle: string
  storyTitle: string
  storyIntro: string
  storyTheme: string
  backgroundImageUrl: string
  lessons: Lesson[]
  onLessonSelect: (lesson: Lesson) => void
}

const AdventureMap = ({ 
  unitTitle, 
  storyTitle, 
  storyIntro, 
  storyTheme,
  backgroundImageUrl,
  lessons, 
  onLessonSelect 
}: AdventureMapProps) => {
  // Generate curved path points for the adventure map
  const generatePathPoints = () => {
    const points = []
    const startX = 50
    const startY = 300
    const amplitude = 100
    const frequency = 0.02
    const steps = 300
    
    for (let i = 0; i <= steps; i++) {
      const x = startX + (i / steps) * (800 - startX)
      const y = startY + amplitude * Math.sin(i * frequency) + 
                amplitude * 0.5 * Math.sin(i * frequency * 2 + Math.PI / 4)
      points.push({ x, y })
    }
    
    return points
  }

  const pathPoints = generatePathPoints()

  // Generate SVG path string
  const generatePathString = () => {
    if (pathPoints.length === 0) return ''
    
    let pathString = `M ${pathPoints[0].x} ${pathPoints[0].y}`
    
    for (let i = 1; i < pathPoints.length; i++) {
      pathString += ` L ${pathPoints[i].x} ${pathPoints[i].y}`
    }
    
    return pathString
  }

  const getThemeStyle = () => {
    switch (storyTheme?.toLowerCase()) {
      case 'fantasy':
        return {
          gradient: 'from-purple-500 via-pink-500 to-indigo-600',
          decoration: '🌟⭐✨🎭',
          bgPattern: '🌙☁️🌈'
        }
      case 'space':
        return {
          gradient: 'from-blue-900 via-purple-900 to-indigo-900',
          decoration: '🚀🪐🌟⭐',
          bgPattern: '🌙⭐✨'
        }
      case 'ocean':
        return {
          gradient: 'from-blue-400 via-teal-500 to-cyan-600',
          decoration: '🐠🐙🌊🪸',
          bgPattern: '🌊🪸🐚'
        }
      case 'forest':
        return {
          gradient: 'from-green-400 via-emerald-500 to-teal-600',
          decoration: '🌲🍄🦋🐿️',
          bgPattern: '🌿🍃🌱'
        }
      default:
        return {
          gradient: 'from-pink-400 via-purple-500 to-indigo-600',
          decoration: '🌟✨💫⭐',
          bgPattern: '🌈✨⭐'
        }
    }
  }

  const themeStyle = getThemeStyle()

  return (
    <div className="relative w-full min-h-screen bg-gray-900 overflow-hidden">
      {/* Background Theme */}
      <div className={`absolute inset-0 bg-gradient-to-br ${themeStyle.gradient}`}>
        <div className="absolute inset-0 opacity-20">
          {themeStyle.bgPattern.split('').map((emoji, index) => (
            <motion.div
              key={index}
              animate={{
                y: [0, -20, 0],
                x: [0, 10, 0],
                rotate: [0, 10, 0],
              }}
              transition={{
                duration: 4 + index,
                repeat: Infinity,
                ease: "easeInOut",
                delay: index * 0.5,
              }}
              className={`absolute text-6xl opacity-30`}
              style={{
                left: `${10 + index * 15}%`,
                top: `${20 + index * 20}%`,
              }}
            >
              {emoji}
            </motion.div>
          ))}
        </div>
      </div>

      {/* Story Header */}
      <motion.div
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="relative z-20 bg-white/10 backdrop-blur-sm p-6 text-center"
      >
        <motion.h1
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 3, repeat: Infinity }}
          className="text-4xl md:text-6xl font-bold text-white kid-friendly mb-4"
        >
          {storyTitle}
        </motion.h1>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-lg text-white/90 max-w-2xl mx-auto leading-relaxed"
        >
          {storyIntro}
        </motion.p>
      </motion.div>

      {/* Adventure Map Container */}
      <div className="relative w-full h-full p-8">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="relative w-full max-w-5xl mx-auto h-[600px] rounded-3xl overflow-hidden"
        >
          {/* Map SVG */}
          <svg
            viewBox="0 0 900 600"
            className="w-full h-full"
            style={{ filter: 'drop-shadow(0 10px 20px rgba(0,0,0,0.3))' }}
          >
            {/* Path Background */}
            <defs>
              <linearGradient id="pathGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#fbbf24" />
                <stop offset="50%" stopColor="#f97316" />
                <stop offset="100%" stopColor="#dc2626" />
              </linearGradient>
              <filter id="glow">
                <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                <feMerge> 
                  <feMergeNode in="coloredBlur"/>
                  <feMergeNode in="SourceGraphic"/>
                </feMerge>
              </filter>
            </defs>

            {/* Adventure Path */}
            <motion.path
              d={generatePathString()}
              stroke="url(#pathGradient)"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 2, ease: "easeInOut" }}
              filter="url(#glow)"
            />

            {/* Lesson Nodes */}
            {lessons.map((lesson, index) => {
              // Find position on the path for this lesson
              const pathPoint = pathPoints[Math.floor((lesson.mapX / 900) * pathPoints.length)]
              
              return (
                <motion.g key={lesson.id}>
                  {/* Node Circle */}
                  <motion.circle
                    cx={pathPoint?.x || lesson.mapX}
                    cy={pathPoint?.y || lesson.mapY}
                    r="25"
                    fill={lesson.isCompleted ? '#10b981' : lesson.isAvailable ? '#3b82f6' : '#6b7280'}
                    stroke={lesson.isCompleted ? '#059669' : lesson.isAvailable ? '#2563eb' : '#4b5563'}
                    strokeWidth="3"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 1 + index * 0.2, duration: 0.5 }}
                    whileHover={{ scale: 1.2 }}
                    className="cursor-pointer"
                    onClick={() => lesson.isAvailable && onLessonSelect(lesson)}
                  />
                  
                  {/* Node Icon/Emoji */}
                  <motion.text
                    x={pathPoint?.x || lesson.mapX}
                    y={pathPoint?.y || lesson.mapY + 8}
                    textAnchor="middle"
                    fontSize="20"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 1.5 + index * 0.2 }}
                  >
                    {lesson.isLocked && <Lock className="w-5 h-5 text-white" />}
                    {lesson.isCompleted && <CheckCircle className="w-5 h-5 text-white" />}
                    {!lesson.isLocked && !lesson.isCompleted && lesson.lessonIcon}
                  </motion.text>
                  
                  {/* Lesson Number */}
                  <motion.text
                    x={pathPoint?.x || lesson.mapX}
                    y={pathPoint?.y || lesson.mapY + 35}
                    textAnchor="middle"
                    fontSize="12"
                    fontWeight="bold"
                    fill="white"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 1.5 + index * 0.2 }}
                  >
                    {lesson.orderNumber}
                  </motion.text>
                </motion.g>
              )
            })}
          </svg>

          {/* Lesson Info Cards */}
          <div className="absolute top-4 right-4 space-y-2 max-w-xs">
            {lessons.slice(0, 3).map((lesson, index) => (
              <motion.div
                key={lesson.id}
                initial={{ x: 100, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 2 + index * 0.2 }}
                className={`bg-white/90 backdrop-blur-sm rounded-xl p-3 text-sm ${
                  !lesson.isAvailable ? 'opacity-50' : ''
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span className="text-lg">{lesson.lessonIcon}</span>
                  <div>
                    <div className="font-semibold text-gray-800">{lesson.title}</div>
                    <div className="text-gray-600 text-xs">{lesson.storyElement}</div>
                  </div>
                  {lesson.isAvailable && !lesson.isCompleted && (
                    <Play className="w-4 h-4 text-blue-500 ml-auto" />
                  )}
                  {lesson.isCompleted && (
                    <CheckCircle className="w-4 h-4 text-green-500 ml-auto" />
                  )}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Sparkle Effects */}
          {[...Array(8)].map((_, index) => (
            <motion.div
              key={index}
              animate={{
                y: [0, -20, 0],
                opacity: [0.3, 1, 0.3],
                scale: [1, 1.2, 1],
              }}
              transition={{
                duration: 3 + index,
                repeat: Infinity,
                ease: "easeInOut",
                delay: index * 0.5,
              }}
              className="absolute w-4 h-4 text-yellow-300 pointer-events-none"
              style={{
                left: `${20 + index * 10}%`,
                top: `${30 + (index % 2) * 40}%`,
              }}
            >
              ✨
            </motion.div>
          ))}
        </motion.div>

        {/* Unit Title at Bottom */}
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, delay: 2.5 }}
          className="text-center mt-8"
        >
          <h2 className="text-3xl font-bold text-white kid-friendly">
            {unitTitle}
          </h2>
          <p className="text-white/80 mt-2">
            Click on the available lessons to begin your adventure!
          </p>
        </motion.div>
      </div>
    </div>
  )
}

export default AdventureMap