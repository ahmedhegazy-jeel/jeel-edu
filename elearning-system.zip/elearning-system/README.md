# Kids E-Learning Adventure System

A fun and interactive e-learning system designed specifically for kids, featuring gamification, storytelling, and animated adventure maps to make learning exciting and engaging.

## 🎯 Project Overview

This e-learning system is designed to teach kids various subjects like Arabic, English, and Math through an engaging, game-like interface. The system features two main parts:

### Admin Part
- **SuperAdmin**: Create curriculums, manage schools, view system-wide dashboards and reports
- **SchoolAdmin**: Create grades/classes, manage teachers, assign curriculums, enroll students
- **Parent**: Track their children's learning progress

### Student Part
- **Interactive Adventure Maps**: Zigzag/curved paths showing lessons as part of an exciting story
- **Gamification**: Points, levels, achievements, and progress tracking
- **Storytelling**: Each unit features engaging stories (e.g., "Saving the Princess of Numbers")
- **Multiple Activity Types**: Text, video, PDF, interactive quizzes, audio reading
- **Cartoon UI**: Kid-friendly design with animations and bright colors

## 🚀 Features

### Adventure Learning System
- **Curved Adventure Maps**: Interactive paths that guide students through lessons
- **Story-Based Learning**: Each unit has a complete story narrative
- **Progressive Unlocking**: Lessons unlock as students complete previous ones
- **Visual Progress**: Color-coded completion status and progress indicators

### Gamification Elements
- **Points System**: Students earn points for completing activities
- **Level Progression**: Students advance through levels based on performance
- **Achievements**: Badges and rewards for milestones
- **Animated Characters**: Cute avatars and animations throughout the interface

### Content Management
- **Flexible Curriculum Structure**: Curriculums → Units → Lessons → Activities
- **Multiple Activity Types**: Text, video, PDF, quizzes, external links, audio
- **Rich Media Support**: Images, audio narration, interactive elements
- **Story Themes**: Fantasy, space, ocean, forest themes for visual appeal

## 🛠 Tech Stack

### Backend
- **Spring Boot 3.1.5**: RESTful API framework
- **MySQL**: Primary database
- **Spring Data JPA**: Database access layer
- **Spring Security**: Authentication and authorization
- **Maven**: Build and dependency management

### Frontend
- **Next.js 14**: React framework with App Router
- **TypeScript**: Type-safe development
- **Tailwind CSS**: Utility-first CSS framework
- **Framer Motion**: Advanced animations and transitions
- **Axios**: HTTP client for API communication
- **React Hot Toast**: User notifications

## 📁 Project Structure

```
elearning-system/
├── backend/
│   ├── src/
│   │   └── main/
│   │       ├── java/
│   │       │   └── com/kids/elearning/
│   │       │       ├── ELearningApplication.java
│   │       │       ├── model/          # Entity classes
│   │       │       ├── controller/     # REST controllers
│   │       │       └── dto/           # Data transfer objects
│   │       └── resources/
│   │           └── application.properties
│   └── pom.xml
└── frontend/
    ├── app/                       # Next.js App Router
    │   ├── curriculum/[id]/      # Dynamic curriculum pages
    │   ├── globals.css          # Global styles
    │   ├── layout.tsx           # Root layout
    │   └── page.tsx             # Homepage
    ├── components/              # React components
    │   ├── AdventureMap.tsx     # Interactive adventure map
    │   ├── CurriculumCard.tsx   # Curriculum display card
    │   └── ProgressHeader.tsx   # Student progress header
    ├── services/               # API services
    │   └── curriculumService.ts # Backend API client
    ├── package.json
    ├── tailwind.config.js
    └── tsconfig.json
```

## 🏃‍♂️ Running the Application

### Prerequisites
- Java 17 or higher
- Maven 3.6 or higher
- Node.js 18 or higher
- MySQL 8.0 or higher
- npm or yarn

### Backend Setup

1. **Navigate to backend directory**:
   ```bash
   cd elearning-system/backend
   ```

2. **Configure database**:
   - Update `src/main/resources/application.properties` with your MySQL credentials
   - Create database: `CREATE DATABASE elearning_db;`

3. **Install dependencies and run**:
   ```bash
   mvn spring-boot:run
   ```

The backend will start on `http://localhost:8080`

### Frontend Setup

1. **Navigate to frontend directory**:
   ```bash
   cd elearning-system/frontend
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Start development server**:
   ```bash
   npm run dev
   ```

The frontend will start on `http://localhost:3000`

## 🎨 Key Components

### AdventureMap Component
The heart of the student experience - features:
- **Dynamic Path Generation**: Creates curved paths using SVG
- **Interactive Lesson Nodes**: Clickable lesson markers on the path
- **Story Themes**: Different visual themes (fantasy, space, ocean, forest)
- **Smooth Animations**: Using Framer Motion for fluid transitions
- **Progress Indicators**: Visual feedback for completed/available/locked lessons

### Curriculum Management
- **Hierarchical Structure**: Curriculums contain units, units contain lessons
- **Story Integration**: Each unit has narrative elements integrated into the map
- **Flexible Activity Types**: Support for various content formats
- **Progress Tracking**: Real-time progress updates and statistics

### Gamification System
- **Points & Levels**: Students earn points and advance through levels
- **Achievement System**: Unlockable badges and rewards
- **Progress Visualization**: Animated progress bars and completion indicators
- **Avatar System**: Customizable student avatars with animations

## 🎯 Story Themes

The system supports multiple story themes to keep learning fresh:

### Fantasy Theme
- **Setting**: Magical kingdom with castles and mythical creatures
- **Characters**: Princesses, wizards, knights, magical animals
- **Colors**: Purple, pink, gold, and rainbow gradients

### Space Theme
- **Setting**: Intergalactic adventures with planets and spaceships
- **Characters**: Astronauts, aliens, robots, cosmic creatures
- **Colors**: Deep blues, purples, and cosmic gradients

### Ocean Theme
- **Setting**: Underwater exploration with sea creatures
- **Characters**: Friendly fish, mermaids, sea captains, dolphins
- **Colors**: Blues, teals, and aqua gradients

### Forest Theme
- **Setting**: Nature adventures with woodland creatures
- **Characters**: Forest animals, wood fairies, friendly trees
- **Colors**: Greens, earth tones, and natural gradients

## 🚀 Development Status

### ✅ Completed Features
- [x] Backend Spring Boot application with basic controllers
- [x] Database models for all entities (User, Curriculum, Unit, Lesson, Activity)
- [x] Frontend Next.js application with TypeScript
- [x] Adventure map component with SVG path generation
- [x] Curriculum selection interface
- [x] Responsive design with Tailwind CSS
- [x] Animations with Framer Motion
- [x] Story-based lesson progression
- [x] Mock data for development

### 🔄 In Progress
- [ ] Database integration and persistence
- [ ] User authentication and authorization
- [ ] Real-time progress tracking
- [ ] Admin dashboard implementation
- [ ] Parent portal for progress monitoring

### 📋 Future Enhancements
- [ ] Voice narration for activities
- [ ] 3D adventure maps
- [ ] Multiplayer learning games
- [ ] AI-powered personalized learning paths
- [ ] Mobile app version
- [ ] Offline learning capabilities
- [ ] Advanced reporting and analytics

## 🎨 Design Principles

1. **Kid-Friendly**: Large buttons, bright colors, playful fonts
2. **Intuitive**: Easy navigation, clear visual hierarchy
3. **Engaging**: Animations, sounds, and interactive elements
4. **Motivating**: Progress tracking, rewards, and achievements
5. **Accessible**: Clear contrast, readable fonts, simple interactions

## 🔧 API Endpoints

### Student Endpoints
- `GET /api/student/curriculums/{studentId}` - Get student's curriculums
- `GET /api/student/curriculum/{curriculumId}/units` - Get curriculum units
- `GET /api/student/unit/{unitId}/lessons` - Get unit lessons
- `GET /api/student/lesson/{lessonId}/activities` - Get lesson activities
- `GET /api/student/student-progress/{studentId}` - Get student progress

### Admin Endpoints
- `GET /api/admin/dashboard` - Get dashboard statistics
- `GET /api/admin/curriculums` - Get all curriculums
- `POST /api/admin/curriculum` - Create new curriculum
- `PUT /api/admin/curriculum/{id}` - Update curriculum
- `DELETE /api/admin/curriculum/{id}` - Delete curriculum

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🎉 Acknowledgments

- **Framer Motion** for smooth animations
- **Tailwind CSS** for rapid UI development
- **Spring Boot** for robust backend architecture
- **Next.js** for modern React development
- **Storytelling** inspired by gamification principles

---

**Built with ❤️ for children's education and learning adventures!** 🌟