#!/bin/bash

# E-Learning System Startup Script
echo "🚀 Starting Kids E-Learning Adventure System"
echo "=========================================="

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "❌ Java is not installed. Please install Java 17 or higher."
    exit 1
fi

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 18 or higher."
    exit 1
fi

echo "✅ Java and Node.js are installed"

# Start backend in background
echo "🔧 Starting backend server..."
cd backend

# Check if Maven is available
if ! command -v mvn &> /dev/null; then
    echo "❌ Maven is not installed. Please install Maven 3.6 or higher."
    exit 1
fi

# Start Spring Boot backend
mvn spring-boot:run &
BACKEND_PID=$!

echo "⏳ Backend starting... (PID: $BACKEND_PID)"
echo "🔧 Backend will be available at: http://localhost:8080"

# Wait for backend to start
echo "⏳ Waiting for backend to be ready..."
sleep 15

# Start frontend
echo "🎨 Starting frontend server..."
cd ../frontend

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "📦 Installing frontend dependencies..."
    npm install
fi

# Start Next.js frontend
npm run dev &
FRONTEND_PID=$!

echo "⏳ Frontend starting... (PID: $FRONTEND_PID)"
echo "🎨 Frontend will be available at: http://localhost:3000"

echo ""
echo "🎉 Both servers are starting!"
echo ""
echo "📋 Quick Access:"
echo "   Frontend: http://localhost:3000"
echo "   Backend API: http://localhost:8080/api"
echo ""
echo "🛑 To stop the servers, run:"
echo "   kill $BACKEND_PID $FRONTEND_PID"
echo ""
echo "🔄 The system is loading with mock data for development."
echo "📚 Visit http://localhost:3000 to start the learning adventure!"

# Keep script running
wait